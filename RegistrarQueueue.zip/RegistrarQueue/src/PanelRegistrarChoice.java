import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class PanelRegistrarChoice extends JPanel {

	
		public PanelRegistrarChoice(CardLayout cl, Container container) {
		
		this.setBounds(100, 100, 919, 576);
		this.setBackground(Color.LIGHT_GRAY);
		this.setVisible(true);
		this.setOpaque(true);
		this.setLayout(null);
		
		JButton btnNewButton = new JButton("Add Client");
		btnNewButton.setForeground(new Color(72, 61, 139));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(container, "PanelAddClient");
	
			}

		});
		
		container.add(this, "PanelRegistrarChoice");
		
		btnNewButton.setFont(new Font("Corbel", Font.PLAIN, 20));
		btnNewButton.setBounds(156, 236, 287, 166);
		add(btnNewButton);
		
		JButton btnEditClient = new JButton("Edit Client");
		btnEditClient.setForeground(new Color(25, 25, 112));
		btnEditClient.setBackground(new Color(255, 255, 255));
		btnEditClient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(container, "PanelEditClient");
			}
		});
		btnEditClient.setFont(new Font("Corbel", Font.PLAIN, 20));
		btnEditClient.setBounds(477, 236, 287, 166);
		add(btnEditClient);
		
		JButton bttnBack = new JButton("back");
		bttnBack.setBackground(new Color(70, 130, 180));
		bttnBack.setForeground(new Color(255, 255, 255));
		bttnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(container,"PanelFirst");
			}
		});
		bttnBack.setBounds(720, 470, 109, 23);
		add(bttnBack);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Jairus\\Pictures\\RegistrarQueue\\RegistrarsChoiceFinalfinal.png"));
		lblNewLabel.setBounds(0, 0, 919, 576);
		add(lblNewLabel);
	}
}