import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Enumeration;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.text.DateFormatter;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JFormattedTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;

public class PanelEditClient extends JPanel {
	private JTextField txtfldStudentReference;
	ButtonGroup buttons = new ButtonGroup();
	JRadioButton radioYes = new JRadioButton();
	JRadioButton radioNo = new JRadioButton();
	private JTextField txtfldSetDate;
	private boolean availability;
	private String pickupDate;
//	public DefaultListModel<String> studentName = new DefaultListModel<String>();
	public DefaultListModel<String> studentNames = new DefaultListModel<String>();
	Student student = new Student();
	public DefaultListModel<Student> studentList = new DefaultListModel<Student>();
	int selectedIndex;
	Student selectedStudent;



	
	public PanelEditClient(CardLayout cl, Container container) {
		
		this.setBounds(100, 100, 919, 576);
		this.setBackground(Color.LIGHT_GRAY);
		this.setVisible(true);
		this.setOpaque(true);
		this.setLayout(null);

		
		
		container.add(this, "PanelEditClient");
		
		
		
	
		
		JButton bttnBack = new JButton("back");
		bttnBack.setForeground(new Color(255, 255, 255));
		bttnBack.setBackground(new Color(70, 130, 180));
		bttnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(container,"PanelRegistrarChoice");
			}
		});
		bttnBack.setBounds(720, 470, 109, 23);
		add(bttnBack);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(197, 147, 519, 58);
		add(scrollPane);
		JList<String> list = new JList<>(studentNames);
		scrollPane.setViewportView(list);
		
		txtfldStudentReference = new JTextField();
		txtfldStudentReference.setBounds(197, 274, 519, 20);
		txtfldStudentReference.setEnabled(false);
		add(txtfldStudentReference);
		txtfldStudentReference.setColumns(10);
		
		JLabel lblReady= new JLabel("Are the documents ready?");
		lblReady.setFont(new Font("Corbel", Font.PLAIN, 18));
		lblReady.setBounds(50, 315, 203, 20);
		add(lblReady);
		
		JLabel lblStudents = new JLabel("Students:");
		lblStudents.setFont(new Font("Corbel", Font.PLAIN, 18));
		lblStudents.setBounds(50, 145, 136, 23);
		add(lblStudents);
		
		txtfldSetDate = new JTextField();
		txtfldSetDate.setColumns(10);
		txtfldSetDate.setBounds(197, 365, 519, 20);
		txtfldSetDate.setEnabled(false);
		
		add(txtfldSetDate);
			radioYes.setBackground(new Color(245, 245, 245));
		

		
		
			radioYes.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					txtfldSetDate.setEnabled(true);
					selectedStudent = studentList.get(selectedIndex);
					selectedStudent.setAvailability(true);
					System.out.println(selectedStudent.getName()+"'s availability: "+selectedStudent.getAvailability());
	
				}
			});
			
			radioYes.setFont(new Font("Corbel", Font.PLAIN, 15));
			
			radioYes.setBounds(259,314,56,23);
			radioYes.setText("Yes");
			this.add(radioYes);
			radioNo.setFont(new Font("Corbel", Font.PLAIN, 15));
			
			
			radioNo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					txtfldSetDate.setEnabled(false);
					selectedStudent = studentList.get(selectedIndex);
					selectedStudent.setAvailability(false);
					System.out.println(selectedStudent.getName()+"'s availability: "+selectedStudent.getAvailability());
					
	
				}
				
			});
			
			radioNo.setBounds(337,314,50,23);
			radioNo.setText("No");
			this.add(radioNo);
	
			
			buttons.add(radioYes);
			buttons.add(radioNo);
			
			
	
			
			
			JButton bttnSelect = new JButton("Select");
			bttnSelect.setForeground(new Color(255, 255, 255));
			bttnSelect.setBackground(new Color(60, 179, 113));
			bttnSelect.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					selectedIndex = list.getSelectedIndex();
					System.out.println(selectedIndex);
					//System.out.println(student.get(1).getName());
					txtfldStudentReference.setText(studentList.get(selectedIndex).getReference());
					txtfldSetDate.setText(studentList.get(selectedIndex).getPickUpDate());
					txtfldSetDate.setEnabled(true);
			}
		});
		bttnSelect.setBounds(580, 229, 136, 23);
		add(bttnSelect);
		
		JLabel lblStudentReference = new JLabel("Student Reference:");
		lblStudentReference.setFont(new Font("Corbel", Font.PLAIN, 18));
		lblStudentReference.setBounds(50, 274, 185, 20);
		add(lblStudentReference);
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.setForeground(new Color(255, 255, 255));
		btnEdit.setBackground(new Color(70, 130, 180));
		btnEdit.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	pickupDate = txtfldSetDate.getText();
		    	System.out.println(selectedIndex);
		    	selectedStudent = studentList.get(selectedIndex);
		    	selectedStudent.setPickUpDate(pickupDate);
		    	txtfldSetDate.setEnabled(false);
		    	System.out.println(selectedStudent.getName()+"'s scheduled date: "+selectedStudent.getPickUpDate());
		    	
		    }
		});

		btnEdit.setBounds(580, 412, 136, 23);
		add(btnEdit);
		
		
		
	
		
		JLabel lblSetPickupDate = new JLabel("Set pick-up date:");
		lblSetPickupDate.setFont(new Font("Corbel", Font.PLAIN, 18));
		lblSetPickupDate.setBounds(50, 365, 134, 20);
		add(lblSetPickupDate);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Jairus\\Pictures\\RegistrarQueue\\Edit Client.png"));
		lblNewLabel.setBounds(0, 0, 919, 576);
		add(lblNewLabel);
	
		




		
		
		
		

	}
}