import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.SystemColor;

public class PanelCheckQueue extends JPanel {

	public int transactionNumber = 25;
	JLabel lblTransactionsLeft;
	
	public PanelCheckQueue(CardLayout cl, Container container) {
		

		this.setBounds(100, 100, 919, 576);
		this.setBackground(Color.LIGHT_GRAY);
		this.setVisible(true);
		this.setOpaque(true);
		this.setLayout(null);
		
		container.add(this, "PanelCheckQueue");
		
		 lblTransactionsLeft = new JLabel("Number of transactions left today: "+transactionNumber);
		lblTransactionsLeft.setFont(new Font("Corbel", Font.PLAIN, 20));
		lblTransactionsLeft.setBounds(294, 232, 321, 23);
		add(lblTransactionsLeft);
		
		JButton btnNewButton = new JButton("Track Reference Number");
		btnNewButton.setBackground(SystemColor.activeCaption);
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cl.show(container,"PanelTrackReference" );
			}
		});
		btnNewButton.setFont(new Font("Corbel", Font.PLAIN, 15));
		btnNewButton.setBounds(339, 286, 228, 23);
		add(btnNewButton);
		
		JButton bttnBack = new JButton("back");
		bttnBack.setForeground(new Color(255, 255, 255));
		bttnBack.setBackground(new Color(70, 130, 180));
		bttnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(container, "PanelFirst");
			}
		});
		bttnBack.setBounds(720, 470, 109, 23);
		add(bttnBack);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Jairus\\Pictures\\RegistrarQueue\\CheckQueueue.png"));
		lblNewLabel.setBounds(0, 0, 919, 576);
		add(lblNewLabel);
	}
}