import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class PanelAddClient extends JPanel {
	private JTextField txtfldStudentName;
	private JTextField txtfldReference;
	public DefaultListModel<String> studentName = new DefaultListModel<String>();
	public DefaultListModel<String> studentReference = new DefaultListModel<String>();
	public DefaultListModel<Student> studentList = new DefaultListModel<Student>();

	public ArrayList<Student> students = new ArrayList<Student>();
	public int transactionNumber = 25;
	JLabel numTransactionsLeft;
	String uniqueId;
	String uniqueId2;
	int  number = 0;
	int year;
	

	Student student;
	boolean button;

	
	JButton btnAddClient;
	private JTextField txtfldStudentNumber;
	public PanelAddClient(CardLayout cl, Container container) {
			
		
		PanelEditClient panelEditClient = new PanelEditClient(cl, container);
		PanelCheckQueue panelCheckQueue = new PanelCheckQueue(cl, container);

		this.setBounds(100, 100, 919, 576);
		this.setBackground(Color.LIGHT_GRAY);
		this.setVisible(true);
		this.setOpaque(true);
		this.setLayout(null);

		container.add(this, "PanelAddClient");

		JLabel lblStudentName = new JLabel("Student Name:");
		lblStudentName.setFont(new Font("Corbel", Font.PLAIN, 20));
		lblStudentName.setBounds(50, 168, 136, 23);
		add(lblStudentName);
		
		txtfldStudentName = new JTextField();
		txtfldStudentName.setColumns(10);
		txtfldStudentName.setBounds(265, 167, 380, 23);
		add(txtfldStudentName);
		
		JLabel lblStudentNumber = new JLabel("Student Number:");
		lblStudentNumber.setFont(new Font("Corbel", Font.PLAIN, 20));
		lblStudentNumber.setBounds(50, 224, 153, 23);
		add(lblStudentNumber);
		
		txtfldStudentNumber = new JTextField();
		txtfldStudentNumber.setColumns(10);
		txtfldStudentNumber.setBounds(263, 223, 382, 23);
		add(txtfldStudentNumber);

		JLabel lblReferenceNumber = new JLabel("Reference Number:");
		lblReferenceNumber.setFont(new Font("Corbel", Font.PLAIN, 20));
		lblReferenceNumber.setBounds(50, 364, 180, 23);
		add(lblReferenceNumber);

		 numTransactionsLeft = new JLabel(Integer.toString(transactionNumber));
		numTransactionsLeft.setFont(new Font("Dialog", Font.PLAIN, 19));
		numTransactionsLeft.setBounds(438, 408, 24, 23);
		add(numTransactionsLeft);

		 btnAddClient = new JButton("Add Client");
		 btnAddClient.setBackground(new Color(60, 179, 113));
		 btnAddClient.setForeground(new Color(255, 255, 255));


		studentName = new DefaultListModel<>(); // Initialize studentName

		
		JButton btnAddAgain = new JButton("Add Again");
		btnAddAgain.setForeground(new Color(255, 255, 255));
		btnAddAgain.setBackground(new Color(70, 130, 180));
		btnAddAgain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAddClient.setEnabled(true);
				txtfldStudentName.setEnabled(true);
		        txtfldStudentNumber.setEnabled(true);

				txtfldReference.setText("");
				txtfldStudentName.setText("");
		        txtfldStudentNumber.setText("");

			}
		});
		btnAddAgain.setBounds(509, 281, 136, 23);
		btnAddAgain.setVisible(false);
		add(btnAddAgain);
		 year = 2023;
		
		 uniqueId2 = Integer.toString(year) + "-"+Integer.toString(number);

		btnAddClient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 uniqueId = String.format("%d-%04d", System.currentTimeMillis(), new Random().nextInt(10000));
			 uniqueId2 = Integer.toString(year) + "-"+Integer.toString(number++);


				txtfldStudentName.setEnabled(false);
				btnAddClient.setEnabled(false);
				btnAddAgain.setVisible(true);
				
				//create a new student
		        student = new Student(txtfldStudentName.getText(),uniqueId2);
		        
		        //We needed to create another list here in add client panel for the check queue panel to use
		        studentList.addElement(student);
		        
		        //add the new student to the student list of the panelEditCLient
		        panelEditClient.studentList.addElement(student);
		        
		        //we need this to show the names to the JList of panelEditCLient since JList cannot iterate an object
		        panelEditClient.studentNames.addElement(txtfldStudentName.getText());


		        //Set the reference JField to the generated UniqueId
		        txtfldReference.setText(uniqueId2);
		        txtfldReference.setDisabledTextColor(Color.BLACK);
		        
		        txtfldStudentNumber.setEnabled(false);

		        
		        //subtract the transaction number declared in the panelCheckQueue
		        panelCheckQueue.transactionNumber--;
		        
		        //set text to the subtracted transaction numner
		        panelCheckQueue.lblTransactionsLeft.setText("Number of transactions left today: "+panelCheckQueue.transactionNumber);
		       
		        //show the new number of transaction left in this panel
		        numTransactionsLeft.setText(Integer.toString(panelCheckQueue.transactionNumber));
		        
		        System.out.println(student.getName()+"'s reference: "+uniqueId2);
		        
		       JOptionPane.showMessageDialog(container, txtfldStudentName.getText()+" has been added","Information", JOptionPane.INFORMATION_MESSAGE);

			}
		});

		btnAddClient.setBounds(265, 281, 136, 23);
		add(btnAddClient);

		txtfldReference = new JTextField();
		txtfldReference.setBackground(new Color(255, 255, 255));
		txtfldReference.setBounds(265, 363, 380, 23);
		txtfldReference.setText("");
		txtfldReference.setEditable(false);
		add(txtfldReference);

		JLabel lblTransactionsLeft = new JLabel("Transactions Left:");
		lblTransactionsLeft.setFont(new Font("Corbel", Font.PLAIN, 20));
		lblTransactionsLeft.setBounds(264, 413, 180, 23);
		add(lblTransactionsLeft);
		
		JButton bttnBack = new JButton("back");
		bttnBack.setBackground(new Color(70, 130, 180));
		bttnBack.setForeground(new Color(255, 255, 255));
		bttnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(container, "PanelRegistrarChoice");
			}
		});
		bttnBack.setBounds(720, 470, 109, 23);
		add(bttnBack);
	
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Jairus\\Pictures\\RegistrarQueue\\AddClients.png"));
		lblNewLabel_1.setBounds(0, 0, 919, 576);
		add(lblNewLabel_1);	
		
		}
}