import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;

public class PanelRegistrarLogin extends JPanel {
	private JTextField txtfldUsername;
	private JPasswordField passwordField;
	private String enteredUsername;
	private String enteredPassword;
	private String[] username = {"neo", "idk"};
	private String[] password = {"123", "345"};


	
	
	/**
	 * Create the panel.
	 */
	public PanelRegistrarLogin(CardLayout cl, Container container) {
		
		this.setBounds(100, 100, 919, 576);
		this.setBackground(Color.LIGHT_GRAY);
		this.setLayout(null);
		
		JButton btnEnter = new JButton("Enter");
		btnEnter.setBackground(new Color(60, 179, 113));
		btnEnter.setForeground(new Color(255, 255, 255));
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnEnter)
				  enteredUsername = txtfldUsername.getText();
					enteredPassword = passwordField.getText();
					
					boolean usernameMatch = false;
					boolean passwordMatch = false;
					
					for (int i = 0; i<username.length;i++) {
						if (enteredUsername.equals(username[i])) {
							usernameMatch = true;	

						} if (enteredPassword.equals(password[i])) {
							passwordMatch = true;

						}
						break;


				
					}
					  if (usernameMatch && passwordMatch) {
				            cl.show(container, "PanelRegistrarChoice");;
				        } 
					

			}
		});
		btnEnter.setBounds(513, 341, 109, 23);
		this.add(btnEnter);
		this.setVisible(true);
		
		container.add(this, "PanelRegistrarLogin");  // Add the panel to the parent container
		
		txtfldUsername = new JTextField();
		txtfldUsername.setBounds(315, 196, 306, 23);
		add(txtfldUsername);
		txtfldUsername.setColumns(10);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Corbel", Font.PLAIN, 15));
		lblUsername.setBounds(315, 163, 136, 23);
		add(lblUsername);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(315, 269, 306, 23);
		add(passwordField);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Corbel", Font.PLAIN, 15));
		lblPassword.setBounds(315, 236, 136, 23);
		add(lblPassword);
		
		JButton bttnBack = new JButton("back");
		bttnBack.setBackground(new Color(70, 130, 180));
		bttnBack.setForeground(new Color(255, 255, 255));
		bttnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cl.show(container, "PanelFirst");
			}
		});
		bttnBack.setBounds(720, 470, 109, 23);
		add(bttnBack);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Jairus\\Pictures\\RegistrarQueue\\Registrar Logiiin.png"));
		lblNewLabel.setBounds(0, 0, 919, 576);
		add(lblNewLabel);

	}
}