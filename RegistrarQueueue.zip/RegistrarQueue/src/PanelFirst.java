import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class PanelFirst extends JPanel {

	/**
	 * Create the panel.
	 */
	public PanelFirst(CardLayout cl, Container container ) {
		this.setBounds(100, 100, 919, 576);
		this.setBackground(Color.LIGHT_GRAY);
		this.setVisible(true);
		this.setOpaque(true);
		this.setLayout(null);
		
		
		container.add(this,"PanelFirst");
		
		JButton bttnCheckQueue = new JButton("Check Queue");
		bttnCheckQueue.setForeground(new Color(25, 25, 112));
		bttnCheckQueue.setBackground(new Color(255, 255, 255));
		bttnCheckQueue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(container, "PanelCheckQueue");
			}
			
		});
		bttnCheckQueue.setFont(new Font("Corbel", Font.PLAIN, 30));
		bttnCheckQueue.setBounds(156, 236, 287, 166);
		add(bttnCheckQueue);
		
		JButton bttnLogin = new JButton("Registrar Log in");
		bttnLogin.setBackground(new Color(255, 255, 255));
		bttnLogin.setForeground(new Color(0, 0, 128));
		bttnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(container, "PanelRegistrarLogin");

			}
		});
		bttnLogin.setFont(new Font("Corbel", Font.PLAIN, 30));
		bttnLogin.setBounds(477, 236, 287, 166);
		add(bttnLogin);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Jairus\\Pictures\\RegistrarQueue\\PanelFirstfinaaal.png"));
		lblNewLabel.setBounds(0, 0, 919, 576);
		add(lblNewLabel);
	}
}